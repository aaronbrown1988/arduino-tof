
java -jar -splash:splashScreen.jpg -Xmx256m trampoline-linux-ia64.jar
     