
java -jar -splash:splashScreen.jpg -Xmx256m trampoline-linux-x86.jar
     