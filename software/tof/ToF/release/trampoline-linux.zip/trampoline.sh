
ava -jar -splash:splashScreen.jpg -Xmx256m trampoline-linux.jar
     