
java -jar -splash:splashScreen.jpg -Xmx256m trampoline-linux-i686.jar
     